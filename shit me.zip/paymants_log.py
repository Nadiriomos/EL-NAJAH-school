import customtkinter as ctk
import tkinter as tk
import sqlite3
import os
import time
from datetime import datetime
from reportlab.lib.pagesizes import A4
from tkinter import  messagebox

def open_full_window():
    # prefs file for remembering last year/group
    PREFS_FILE = "prefs.json"

    def load_prefs():
        if os.path.exists(PREFS_FILE):
            try:
                with open(PREFS_FILE, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                return {}
        return {}

    def save_prefs(p):
        try:
            with open(PREFS_FILE, "w", encoding="utf-8") as f:
                json.dump(p, f)
        except Exception:
            pass

    # academic year helpers
    def current_academic_year_from_today():
        now = datetime.now()
        # if month >= Aug -> academic year = current year, else previous year
        return now.year if now.month >= 8 else now.year - 1

    def months_for_academic_year(academic_year):
        months_names = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
        order = []
        for m in range(8, 13):
            label = months_names[m - 1]
            order.append((label + " " + str(academic_year), academic_year, m))
        for m in range(1, 8):
            label = months_names[m - 1]
            order.append((label + " " + str(academic_year + 1), academic_year + 1, m))
        return order

    # prepare window
    full_win = ctk.CTkToplevel(ElNajahSchool)
    full_win.title("Payments History Logs")
    full_win.state("zoomed")
    full_win.geometry(f"{ElNajahSchool.winfo_screenwidth()}x{ElNajahSchool.winfo_screenheight()}+0+0")
    full_win.grab_set()

    # Title
    title_label = ctk.CTkLabel(full_win, text="Payments History", font=("Arial", 30, "bold"))
    title_label.pack(pady=(0, 10))

    # load prefs
    prefs = load_prefs()
    default_academic = prefs.get("last_academic_year", current_academic_year_from_today())
    default_group = prefs.get("last_group", None)

    # top selectors row
    sel_frame = ctk.CTkFrame(full_win, fg_color="transparent")
    sel_frame.pack(pady=10, anchor="center")

    now_year = datetime.now().year
    years = [str(y) for y in range(now_year - 6, now_year + 6)]
    year_var = ctk.StringVar(value=str(default_academic))
    group_names = get_all_groups()
    if not group_names:
        group_names = ["(no groups)"]
    group_var = ctk.StringVar(value=default_group or group_names[0])

    # grid layout for compact row
    sel_frame.grid_columnconfigure(0, weight=0)
    sel_frame.grid_columnconfigure(1, weight=0)
    sel_frame.grid_columnconfigure(2, weight=0)
    sel_frame.grid_columnconfigure(3, weight=0)
    sel_frame.grid_columnconfigure(4, weight=0)

    ctk.CTkLabel(sel_frame, text="Academic Year:", font=("Arial", 14)).grid(row=0, column=0, padx=6)
    year_option = ctk.CTkOptionMenu(sel_frame, values=years, variable=year_var)
    year_option.grid(row=0, column=1, padx=6)

    ctk.CTkLabel(sel_frame, text="Group:", font=("Arial", 14)).grid(row=0, column=2, padx=6)
    group_option = ctk.CTkOptionMenu(sel_frame, values=group_names, variable=group_var)
    group_option.grid(row=0, column=3, padx=6)

    # actions
    actions_frame = ctk.CTkFrame(sel_frame, fg_color="transparent")
    actions_frame.grid(row=0, column=4, padx=6)

    def action_export_pdf():
        export_current_view_pdf()
    def action_refresh():
        refresh_full_tree()
    def action_close():
        prefs["last_academic_year"] = int(year_var.get())
        prefs["last_group"] = group_var.get()
        save_prefs(prefs)
        full_win.destroy()

    ctk.CTkButton(actions_frame, text="Export PDF", command=action_export_pdf).pack(side="left", padx=4)
    def on_edit_payment_click():
        sel = tree_full.selection()
        if not sel:
            messagebox.showerror("No selection", "Select a student first.")
            return
        vals = tree_full.item(sel[0], "values")
        try:
            student_id = int(vals[0])
        except Exception:
            messagebox.showerror("Error", "Could not read student ID from the table.")
            return

        # Optional: pass a refresher so your history/main view updates after Save.
        # Replace 'refresh_payment_history_for' with your real function if you have one.
        def _after_save(_sid):
            try:
                # Example: if you have a function that redraws the payment history for selected student
                # refresh_payment_history_for(_sid)
                pass
            except Exception:
                pass

        open_edit_payment_modal(student_id, on_saved=_after_save)

    ctk.CTkButton(actions_frame,text="Edit Payment",fg_color="#43C24E",command=on_edit_payment_click).pack(side="left", padx=4)
    ctk.CTkButton(actions_frame, text="Refresh", command=action_refresh).pack(side="left", padx=4)
    ctk.CTkButton(actions_frame, text="Close", fg_color="#F13D3D", command=action_close).pack(side="left", padx=4)

    # Separator
    sep = ttk.Separator(full_win, orient="horizontal")
    sep.pack(fill="x", pady=5)

    # Treeview area
    tree_frame = ctk.CTkFrame(full_win, fg_color="transparent")
    tree_frame.pack(fill="both", expand=True)

    tv_columns = ["id", "name"]  # will add month headers dynamically
    tree_full = ttk.Treeview(tree_frame, columns=tv_columns, show="headings", style="Full.Treeview")
    tree_full.pack(side="left", fill="both", expand=True)

    vsb = ttk.Scrollbar(tree_frame, orient="vertical", command=tree_full.yview)
    vsb.pack(side="right", fill="y")
    tree_full.configure(yscrollcommand=vsb.set)

    style = ttk.Style()
    style.configure("Full.Treeview", rowheight=28)
    tree_full.tag_configure("evenrow", background="#f2f2f2")
    tree_full.tag_configure("oddrow", background="#ffffff")


    # helper to map columns and refresh
    def build_month_headers_and_columns(academic_year):
        nonlocal tv_columns
        months = months_for_academic_year(int(academic_year))
        # rebuild tv_columns
        tv_columns = ["id", "name"] + [m[0] for m in months]  # labels as column ids (unique)
        # clear existing tree columns
        tree_full["columns"] = tv_columns
        # configure headings & widths
        tree_full.heading("id", text="ID")
        tree_full.column("id", width=60, anchor="center")
        tree_full.heading("name", text="Name")
        tree_full.column("name", width=150, anchor="w")
        # month columns
        for label, y, mnum in months:
            tree_full.heading(label, text=label)
            tree_full.column(label, width=80, anchor="center")

        return months  # return month tuples list

    # build initial headers
    months_list = build_month_headers_and_columns(year_var.get())

    # function to fetch rows for selected group & academic year
    def get_students_for_group(group_name):
        conn = sqlite3.connect("elnajah.db")
        c = conn.cursor()
        try:
            c.execute("""
                SELECT s.id, s.name
                FROM students s
                JOIN student_group sg ON s.id = sg.student_id
                JOIN groups g ON sg.group_id = g.id
                WHERE g.name = ?
                ORDER BY s.id ASC
            """, (group_name,))
            return c.fetchall()
        finally:
            conn.close()

    # helper to fetch payment latest record for a student/year/month
    def fetch_payment(student_id, year, month):
        conn = sqlite3.connect("elnajah.db")
        c = conn.cursor()
        try:
            c.execute("""
                SELECT paid, payment_date
                FROM payments
                WHERE student_id = ? AND year = ? AND month = ?
                ORDER BY payment_date DESC
                LIMIT 1
            """, (student_id, year, month))
            return c.fetchone()  # (paid, payment_date) or None
        finally:
            conn.close()

    # populate tree
    def refresh_full_tree():
        nonlocal months_list
        tree_full.delete(*tree_full.get_children())

        # rebuild headers if year changed
        months_list = build_month_headers_and_columns(year_var.get())

        group_name = group_var.get()
        if group_name == "(no groups)":
            return

        students = get_students_for_group(group_name)

        conn = sqlite3.connect("elnajah.db")
        c = conn.cursor()

        for i, (sid, name) in enumerate(students):
            # fetch join_date once for the student
            c.execute("SELECT join_date FROM students WHERE id = ?", (sid,))
            row = c.fetchone()
            join_date = row[0] if row else None

            row_values = [sid, name]

            for label, y, mnum in months_list:
                pr = fetch_payment(sid, y, mnum)

                if join_date:
                    join_dt = datetime.strptime(join_date, "%Y-%m-%d")

                    if (y < join_dt.year) or (y == join_dt.year and mnum < join_dt.month):
                        # Before the join month → no record
                        row_values.append("no record")
                    else:
                        # Same month or after → normal check
                        if pr is None:
                            row_values.append("Unpaid")
                        else:
                            paid, pdate = pr
                            row_values.append(paid if paid else "Unpaid")
                else:
                    # If join_date missing, default to unpaid if no record
                    if pr is None:
                        row_values.append("Unpaid")
                    else:
                        paid, pdate = pr
                        row_values.append(paid if paid else "Unpaid")

            # 👇 these lines must be inside the loop
            tags = ("evenrow" if i % 2 == 0 else "oddrow",)
            tree_full.insert("", "end", values=row_values, tags=tags)

        conn.close()



    # toggle logic when clicking a month cell
    def on_tree_click(ev):
        # need to identify region & column & row
        region = tree_full.identify_region(ev.x, ev.y)
        if region != "cell":
            return
        col = tree_full.identify_column(ev.x)  # like '#1'
        row_id = tree_full.identify_row(ev.y)
        if not row_id:
            return
        try:
            col_idx = int(col.replace("#", "")) - 1  # 0-based
        except Exception:
            return
        # columns: 0 => id, 1 => name, 2.. => months
        if col_idx < 2:
            return  # do nothing for id/name
        values = tree_full.item(row_id, "values")
        if not values:
            return
        student_id = int(values[0])
        # determine month tuple
        month_index = col_idx - 2
        if month_index < 0 or month_index >= len(months_list):
            return
        _, year_for_cell, month_for_cell = months_list[month_index]

        # fetch existing payment
        conn = sqlite3.connect("elnajah.db")
        c = conn.cursor()
        try:
            c.execute("""
                SELECT id, paid FROM payments
                WHERE student_id = ? AND year = ? AND month = ?
                ORDER BY payment_date DESC
                LIMIT 1
            """, (student_id, year_for_cell, month_for_cell))
            row = c.fetchone()
            nowstr = datetime.now().strftime("%Y-%m-%d")
            if row is None:
                # no record -> insert paid (as toggle behavior)
                c.execute("""
                    INSERT INTO payments (student_id, year, month, paid, payment_date)
                    VALUES (?, ?, ?, ?, ?)
                """, (student_id, year_for_cell, month_for_cell, "paid", nowstr))
            else:
                pid, paid = row
                if paid == "paid":
                    # set to unpaid (update)
                    c.execute("""
                        UPDATE payments SET paid = ?, payment_date = ? WHERE id = ?
                    """, ("unpaid", nowstr, pid))
                else:
                    # set to paid
                    c.execute("""
                        UPDATE payments SET paid = ?, payment_date = ? WHERE id = ?
                    """, ("paid", nowstr, pid))
            conn.commit()
        except Exception as e:
            conn.rollback()
            messagebox.showerror("DB Error", str(e))
        finally:
            conn.close()

        # refresh the row or entire tree
        refresh_full_tree()

    tree_full.bind("<Button-1>", on_tree_click)

    # handler when year or group changes
    def on_year_or_group_change(*_):
        # update group option menu values (in case groups changed)
        current_groups = get_all_groups()
        if current_groups:
            group_option.configure(values=current_groups)
            # if selected group not in list, set to first
            if group_var.get() not in current_groups:
                group_var.set(current_groups[0])
        # save prefs
        prefs["last_academic_year"] = int(year_var.get())
        prefs["last_group"] = group_var.get()
        save_prefs(prefs)
        # refresh tree
        refresh_full_tree()

    year_var.trace_add("write", on_year_or_group_change)
    group_var.trace_add("write", on_year_or_group_change)

    # initial population
    refresh_full_tree()

    # Export current view to PDF (includes payment_date if paid)
    def export_current_view_pdf():
        # === Prepare rows with month data as (status, date) tuples ===
        rows = []
        headers = ["ID", "Name"] + [label for label, _, _ in months_list]

        for iid in tree_full.get_children():
            vals = tree_full.item(iid, "values")
            sid = int(vals[0])
            row = [vals[0], vals[1]]

            # fetch join_date once
            conn = sqlite3.connect("elnajah.db")
            c = conn.cursor()
            c.execute("SELECT join_date FROM students WHERE id = ?", (sid,))
            join_row = c.fetchone()
            conn.close()
            join_date = join_row[0] if join_row else None
            join_dt = datetime.strptime(join_date, "%Y-%m-%d") if join_date else None

            for label, y, mnum in months_list:
                pr = fetch_payment(sid, y, mnum)

                if join_dt and (y < join_dt.year or (y == join_dt.year and mnum < join_dt.month)):
                    row.append(("no record", ""))
                else:
                    if pr is None:
                        row.append(("Unpaid", ""))
                    else:
                        paid, pdate = pr
                        if paid == "paid":
                            row.append(("Paid", pdate))
                        elif paid == "unpaid":
                            row.append(("Unpaid", ""))
                        else:
                            row.append(("no record", ""))

            rows.append(row)

        if not rows:
            messagebox.showinfo("No Data", "Nothing to export.")
            return

        # === PDF Setup ===
        os.makedirs("exports", exist_ok=True)
        ts = datetime.now().strftime("%Y_%m_%d_%H_%M_%S")
        filename = os.path.join("exports", f"payments_{group_var.get()}_{year_var.get()}_{ts}.pdf")

        page_size = landscape(A4)
        pdf = canvas.Canvas(filename, pagesize=page_size)
        page_w, page_h = page_size

        left_margin, right_margin, top_margin, bottom_margin = 30, 30, 40, 40
        row_padding, line_height = 6, 11

        # === Dynamic Column Widths ===
        available = page_w - left_margin - right_margin
        n_months = len(months_list)
        id_min, id_pref = 35, 70
        name_min, name_pref = 70, 250
        month_min = 60

        id_w = id_pref
        name_w = name_pref
        remaining = available - (id_w + name_w)
        month_base = max(month_min, remaining // n_months if n_months else 0)
        col_widths = [id_w, name_w] + [month_base] * n_months

        # Adjust if widths exceed available space
        total_w = sum(col_widths)
        if total_w > available:
            # shrink Name first
            overflow = total_w - available
            name_w = max(name_min, name_w - overflow)
            col_widths[1] = name_w
            total_w = sum(col_widths)
            if total_w > available:
                # shrink ID if still overflow
                overflow = total_w - available
                id_w = max(id_min, id_w - overflow)
                col_widths[0] = id_w

        # Recalculate month widths if leftover space
        leftover = available - sum(col_widths)
        if leftover > 0:
            col_widths[-1] += leftover  # add to last month column

        col_x = [left_margin]
        for w in col_widths[:-1]:
            col_x.append(col_x[-1] + w)

        # === Title and headers ===
        pdf.setFont("Helvetica-Bold", 14)
        title = f"Payments — Group: {group_var.get()} — Academic Year: {year_var.get()}"
        pdf.drawString(left_margin, page_h - top_margin + 10, title)
        pdf.setFont("Helvetica-Bold", 10)

        y = page_h - top_margin - 10
        for i, hdr in enumerate(headers):
            pdf.drawString(col_x[i] + 2, y, str(hdr))
        y -= 16
        pdf.setFont("Helvetica", 9)

        def draw_header_on_new_page():
            nonlocal y
            pdf.setFont("Helvetica-Bold", 10)
            y = page_h - top_margin - 10
            for i, hdr in enumerate(headers):
                pdf.drawString(col_x[i] + 2, y, str(hdr))
            y -= 16
            pdf.setFont("Helvetica", 9)

        def max_chars_for_width(w):
            return max(8, int((w - 6) // 6))

        # === Draw rows ===
        for row in rows:
            # Name wrapping
            name_text = str(row[1])
            name_max_chars = max_chars_for_width(col_widths[1])
            name_lines = textwrap.wrap(name_text, width=name_max_chars) or [""]

            # Determine max lines for this row (name vs 2-line months)
            row_height = max(line_height * len(name_lines), line_height * 2) + row_padding

            if y - row_height < bottom_margin:
                pdf.showPage()
                draw_header_on_new_page()

            # Draw ID
            pdf.drawString(col_x[0] + 2, y, str(row[0]))

            # Draw Name
            for li, ln in enumerate(name_lines):
                pdf.drawString(col_x[1] + 2, y - (li * line_height), ln)

            # Draw Month cells (status + date)
            for i in range(n_months):
                status, date = row[2 + i]
                pdf.drawString(col_x[2 + i] + 2, y, status)
                if date:
                    pdf.drawString(col_x[2 + i] + 2, y - line_height, date)

            y -= row_height

        pdf.save()
        messagebox.showinfo("Export Complete", f"PDF saved:\n{filename}")